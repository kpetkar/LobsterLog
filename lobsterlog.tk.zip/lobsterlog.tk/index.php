<!DOCTYPE html>
<html>
  <head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <meta charset="utf-8">
    <title>Heatmaps</title>
    <style>
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      #map {
        height: 100%;
      }
      /*#floating-panel {
        position: absolute;
        top: 10px;
        left: 25%;
        z-index: 5;
        background-color: #fff;
        padding: 5px;
        border: 1px solid #999;
        text-align: center;
        font-family: 'Roboto','sans-serif';
        line-height: 30px;
        padding-left: 10px;
      }
      #floating-panel {
        background-color: #fff;
        border: 1px solid #999;
        left: 25%;
        padding: 5px;
        position: absolute;
        top: 10px;
        z-index: 5;
      }*/
    </style>
  </head>

  <body>
    <!--<div id="floating-panel>
      <button onclick="toggleHeatmap()">Toggle Heatmap</button>
      <button onclick="changeGradient()">Change gradient</button>
      <button onclick="changeRadius()">Change radius</button>
      <button onclick="changeOpacity()">Change opacity</button>
    </div>-->
    <div id="map"></div>
    <script>

      // This example requires the Visualization library. Include the libraries=visualization
      // parameter when you first load the API. For example:
      // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=visualization">

      var map, heatmap;

      function initMap() {
        map = new google.maps.Map(document.getElementById('map'), {
          zoom: 9,
          center: {lat: 44.7728, lng: -66.434},
          mapTypeId: google.maps.MapTypeId.SATELLITE
        });

        heatmap = new google.maps.visualization.HeatmapLayer({
          data: getPoints(),
          map: map,
          radius: 12
        });
      }

      function toggleHeatmap() {
        heatmap.setMap(heatmap.getMap() ? null : map);
      }

      function changeGradient() {
        var gradient = [
          'rgba(0, 255, 255, 0)',
          'rgba(0, 255, 255, 1)',
          'rgba(0, 191, 255, 1)',
          'rgba(0, 127, 255, 1)',
          'rgba(0, 63, 255, 1)',
          'rgba(0, 0, 255, 1)',
          'rgba(0, 0, 223, 1)',
          'rgba(0, 0, 191, 1)',
          'rgba(0, 0, 159, 1)',
          'rgba(0, 0, 127, 1)',
          'rgba(63, 0, 91, 1)',
          'rgba(127, 0, 63, 1)',
          'rgba(191, 0, 31, 1)',
          'rgba(255, 0, 0, 1)'
        ]
        heatmap.set('gradient', heatmap.get('gradient') ? null : gradient);
      }

      function changeRadius() {
        heatmap.set('radius', heatmap.get('radius') ? null : 20);
      }

      function changeOpacity() {
        heatmap.set('opacity', heatmap.get('opacity') ? null : 0.2);
      }

      function getPoints() {
        return [
          new google.maps.LatLng(44.7728, -66.3096),
          new google.maps.LatLng(44.7730, -66.3087),
          new google.maps.LatLng(44.7430, -66.3097),
          new google.maps.LatLng(44.7930, -66.3077),
          new google.maps.LatLng(44.7130, -66.3067),
          new google.maps.LatLng(44.7830, -66.3127),
          new google.maps.LatLng(44.7530, -66.3087),
          new google.maps.LatLng(44.7730, -66.3187),
          new google.maps.LatLng(44.7270, -66.3027),
          new google.maps.LatLng(44.7730, -66.3174),
          new google.maps.LatLng(44.7430, -66.3091),
          new google.maps.LatLng(44.7633, -66.3210),
          new google.maps.LatLng(44.9293, -66.2987),
          new google.maps.LatLng(44.83479832, -66.13987),
          new google.maps.LatLng(44.7528, -66.28497),
          new google.maps.LatLng(44.7334, -66.1994094308),
          new google.maps.LatLng(44.7296, -66.3027),
          new google.maps.LatLng(44.7540, -66.3097),
          new google.maps.LatLng(44.7740, -66.3207),
          new google.maps.LatLng(44.7270, -66.3027),
          new google.maps.LatLng(44.7710, -66.3174),
          new google.maps.LatLng(44.7529, -66.3091),
          new google.maps.LatLng(44.7951, -66.3210),
          new google.maps.LatLng(44.7550, -66.2987),
          new google.maps.LatLng(44.7301, -66.3028),
          new google.maps.LatLng(44.7102, -66.3012),
          new google.maps.LatLng(44.7334, -66.3),
          new google.maps.LatLng(44.7296, -66.31334)
        ];
      }
    </script>
    <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBUkMOzv35-CCmcfGWgREZoDPTsgvxNzDY&libraries=visualization&callback=initMap">
    </script>
    <script>
    function callPHP() {
   // var url = "boshencui.com/getAllTraps.php";
   var url = "http://boshencui.com/getAllTraps.php"
    var method = "POST";

// You REALLY want async = true.
// Otherwise, it'll block ALL execution waiting for server response.
var async = true;
var data;

var request = new XMLHttpRequest();

// Before we send anything, we first have to say what we will do when the
// server responds. This seems backwards (say how we'll respond before we send
// the request? huh?), but that's how Javascript works.
// This function attached to the XMLHttpRequest "onload" property specifies how
// the HTTP response will be handled. 
request.onload = function () {
   var status = request.status; // HTTP response status, e.g., 200 for "200 OK"
   data = request.responseText; // Returned data, e.g., an HTML document.

   window.alert(data+"");
}
window.alert("function is called");
request.open(method, url, async);

request.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
// Or... request.setRequestHeader("Content-Type", "text/plain;charset=UTF-8");
// Or... whatever

// Actually sends the request to the server.
request.send();
return data;
}    
    </script>
  </body>
</html>